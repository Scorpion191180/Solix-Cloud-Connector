"""Read-only, cached access to Audi Connect vehicle data.

Audi's cloud should not be polled for every browser refresh.  This client keeps
the last successful result for 15 minutes and always returns that cache to the
API once it exists.
"""

import asyncio
import os
import time
from datetime import datetime, timezone
from typing import Any

import aiohttp


CACHE_SECONDS = 15 * 60


class AudiClient:
    """Small adapter around audiconnectpy for the dashboard API."""

    def __init__(self) -> None:
        self._email = os.getenv("AUDI_EMAIL", "").strip()
        self._password = os.getenv("AUDI_PASSWORD", "")
        self._country = os.getenv("AUDI_COUNTRY", "DE").strip().upper()
        self._spin = os.getenv("AUDI_SPIN", "")
        self._session: aiohttp.ClientSession | None = None
        self._api: Any = None
        self._cache: dict[str, Any] | None = None
        self._last_success: float | None = None
        self._last_error: str | None = None
        self._lock = asyncio.Lock()

    @property
    def configured(self) -> bool:
        return bool(self._email and self._password)

    def _empty_payload(self) -> dict[str, Any]:
        return {
            "configured": self.configured,
            "available": False,
            "cached": False,
            "cache_age_seconds": None,
            "last_update": None,
            "error": None,
            "vehicle_name": None,
            "vin": None,
            "battery_percent": None,
            "fuel_percent": None,
            "electric_range_km": None,
            "total_range_km": None,
            "charging": None,
            "plug_connected": None,
        }

    @staticmethod
    def _plain(value: Any, depth: int = 0) -> Any:
        """Convert audiconnectpy model objects into a small, safe value tree."""
        if depth > 5:
            return None
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, dict):
            return {str(k): AudiClient._plain(v, depth + 1) for k, v in value.items()}
        if isinstance(value, (list, tuple, set)):
            return [AudiClient._plain(item, depth + 1) for item in value]
        if hasattr(value, "__dict__"):
            return {
                key: AudiClient._plain(item, depth + 1)
                for key, item in vars(value).items()
                if not key.startswith("_")
            }
        return str(value)

    @staticmethod
    def _leaf_values(value: Any, prefix: str = "") -> dict[str, Any]:
        """Flatten a vehicle model so different audiconnectpy model versions work."""
        values: dict[str, Any] = {}
        if isinstance(value, dict):
            for key, item in value.items():
                key_name = str(key).lower().replace("-", "_")
                next_prefix = f"{prefix}_{key_name}".strip("_")
                values.update(AudiClient._leaf_values(item, next_prefix))
        elif isinstance(value, list):
            for item in value:
                values.update(AudiClient._leaf_values(item, prefix))
        elif prefix:
            values[prefix] = value
            values.setdefault(prefix.split("_")[-1], value)
        return values

    @staticmethod
    def _find(values: dict[str, Any], *names: str) -> Any:
        for name in names:
            key = name.lower().replace("-", "_")
            if key in values and values[key] is not None:
                return values[key]
        for name in names:
            needle = name.lower().replace("-", "_")
            for key, value in values.items():
                if key.endswith(f"_{needle}") and value is not None:
                    return value
        return None

    @staticmethod
    def _number(value: Any) -> int | float | None:
        if value is None or isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            return value
        text = str(value).replace("%", "").replace(",", ".").strip()
        try:
            number = float(text)
            return int(number) if number.is_integer() else number
        except ValueError:
            return None

    @staticmethod
    def _bool(value: Any) -> bool | None:
        if isinstance(value, bool):
            return value
        if value is None:
            return None
        text = str(value).lower().strip()
        if text in {"true", "1", "yes", "on", "connected", "plugged", "charging", "active"}:
            return True
        if text in {"false", "0", "no", "off", "disconnected", "unplugged", "not_charging", "inactive"}:
            return False
        return None

    def _normalise_vehicle(self, vehicle: Any) -> dict[str, Any]:
        values = self._leaf_values(self._plain(vehicle))
        charging = self._bool(self._find(values, "is_charging", "charging", "charging_state", "charging_status"))
        plug_connected = self._bool(self._find(values, "plug_connected", "is_plug_connected", "plug_state", "plug"))

        return {
            "vehicle_name": self._find(values, "vehicle_name", "name", "model"),
            "vin": self._find(values, "vin", "vehicle_identification_number"),
            "battery_percent": self._number(self._find(values, "battery_level", "battery_percent", "battery_percentage", "soc", "state_of_charge")),
            "fuel_percent": self._number(self._find(values, "fuel_level", "fuel_percent", "fuel_percentage")),
            "electric_range_km": self._number(self._find(values, "electric_range_km", "electric_range", "remaining_electric_range")),
            "total_range_km": self._number(self._find(values, "total_range_km", "total_range", "remaining_range", "combined_range")),
            "charging": charging,
            "plug_connected": plug_connected,
        }

    async def _refresh_from_cloud(self) -> dict[str, Any]:
        # Lazy import keeps a missing optional package from breaking the Solix app.
        try:
            from audiconnectpy import AudiConnect
        except ImportError as exc:
            raise RuntimeError("audiconnectpy ist nicht installiert") from exc

        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()

        if self._api is None:
            self._api = AudiConnect(
                self._session,
                self._email,
                self._password,
                self._country,
                self._spin,
            )

        await self._api.async_update()
        vehicles = getattr(self._api, "vehicles", None)
        if isinstance(vehicles, dict):
            vehicle = next(iter(vehicles.values()), None)
        elif isinstance(vehicles, (list, tuple)):
            vehicle = vehicles[0] if vehicles else None
        else:
            vehicle = None
        if vehicle is None:
            raise RuntimeError("Kein Fahrzeug im myAudi-Konto gefunden")

        payload = self._empty_payload()
        payload.update(self._normalise_vehicle(vehicle))
        payload.update(
            {
                "available": True,
                "cached": False,
                "cache_age_seconds": 0,
                "last_update": datetime.now(timezone.utc).isoformat(),
                "error": None,
            }
        )
        return payload

    def _cached_payload(self) -> dict[str, Any] | None:
        if self._cache is None or self._last_success is None:
            return None
        payload = dict(self._cache)
        payload["cached"] = True
        payload["cache_age_seconds"] = int(time.time() - self._last_success)
        payload["error"] = self._last_error
        return payload

    async def get_live(self) -> dict[str, Any]:
        """Return cached Audi data; fetch at most once every 15 minutes."""
        if not self.configured:
            payload = self._empty_payload()
            payload["error"] = "AUDI_EMAIL oder AUDI_PASSWORD ist nicht gesetzt"
            return payload

        cached = self._cached_payload()
        if cached and cached["cache_age_seconds"] < CACHE_SECONDS:
            return cached

        async with self._lock:
            cached = self._cached_payload()
            if cached and cached["cache_age_seconds"] < CACHE_SECONDS:
                return cached
            try:
                self._cache = await self._refresh_from_cloud()
                self._last_success = time.time()
                self._last_error = None
                return dict(self._cache)
            except Exception as exc:  # The dashboard must stay usable if Audi is unavailable.
                self._last_error = str(exc)
                cached = self._cached_payload()
                if cached:
                    return cached
                payload = self._empty_payload()
                payload["error"] = self._last_error
                return payload

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
